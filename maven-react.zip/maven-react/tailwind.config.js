/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['"Source Serif 4"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        cream: {
          50:  '#FDFCF8',
          100: '#FAFAF7',
          150: '#F4F4EF',
          200: '#ECECE5',
          300: '#DEDED5',
        },
        ink: {
          300: '#B4BCCC',
          400: '#8E98B1',
          500: '#6B7894',
          600: '#475777',
          700: '#28375A',
          800: '#1A2844',
          900: '#0F1E3D',
        },
        navy: {
          50:  '#EDF0F6',
          100: '#DCE1EB',
          200: '#BBC4D6',
          300: '#8796B5',
          400: '#4A5B7E',
          500: '#2B3E63',
          600: '#1E2F52',
          700: '#132245',
          900: '#0F1E3D',
        },
        terra: {
          50:  '#FBEFEA',
          100: '#F5D9CE',
          200: '#E9B29D',
          300: '#D88566',
          400: '#C96B48',
          500: '#B4542F',
          600: '#9A4224',
          700: '#7E351C',
        },
      },
      animation: {
        'fade-up':    'fadeUp 0.4s cubic-bezier(0.16,1,0.3,1)',
        'fade-in':    'fadeIn 0.3s ease-out',
        'pulse-soft': 'pulseSoft 2s ease-in-out infinite',
        'spin-slow':  'spin 1s linear infinite',
      },
      keyframes: {
        fadeUp: {
          '0%':   { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        pulseSoft: {
          '0%,100%': { opacity: '0.6' },
          '50%':     { opacity: '1' },
        },
      },
    },
  },
  // Ensure dynamically-added classes are preserved by the JIT
  safelist: [
    'animate-fade-up',
    'animate-fade-in',
    'animate-pulse-soft',
  ],
  plugins: [],
};
