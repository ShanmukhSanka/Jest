# MAVEN — Installation & Integration

## 1. Dependencies

Your existing `package.json` already has everything MAVEN needs. Verify these versions (you already have them at these or newer):

```json
"dependencies": {
  "react":            "^19.0.0",
  "react-dom":        "^19.0.0",
  "framer-motion":    "^12.38.0",
  "lucide-react":     "^1.8.0",
  "clsx":             "^2.1.1"
},
"devDependencies": {
  "tailwindcss":      "^3.4.17",
  "postcss":          "^8.5.10",
  "autoprefixer":     "^10.5.4"
}
```

No new installs required. If `lucide-react@1.8.0` is missing specific icons (`Wrench`, `LineChart`, `Code2`, `MessageSquare`, `PanelRight`, `Maximize2`, `RotateCcw`, `ShieldCheck`, `Clock`, `Paperclip`, `Send`, `Square`, `Plus`, `History`, `X`, `ChevronDown`, `Check`, `Copy`, `ThumbsUp`, `ThumbsDown`, `Sparkles`, `Upload`, `Download`, `Play`, `Ticket`, `Trash2`, `Search`), upgrade to a newer `lucide-react` — the current ecosystem is on `^0.400.0+`. `1.8.0` is a different package vintage; double-check the name.

## 2. File layout

```
src/
├── index.css                                (Tailwind directives + fonts)
├── styles/
│   └── prose.css                            (AI-answer typography)
└── components/
    └── Maven/
        ├── ActionBar.js
        ├── AiMessage.js
        ├── Autocomplete.js
        ├── Composer.js
        ├── Header.js
        ├── HistoryPane.js
        ├── index.js                         (barrel)
        ├── Maven.css                        (component styles)
        ├── Maven.js                         (top-level)
        ├── MavenLogo.js
        ├── MessageList.js
        ├── mockService.js                   (fake backend — swap later)
        ├── PrivacyBar.js
        ├── ReasoningCard.js
        ├── ReasoningStep.js
        ├── SuggestionCard.js
        ├── suggestionsCatalog.js            (prompts / actions / slashes)
        ├── ThinkingIndicator.js             (25 variants)
        ├── thinking-indicator.css
        ├── UserMessage.js
        └── Welcome.js

tailwind.config.js                           (MAVEN palette + keyframes)
postcss.config.js
```

## 3. Tailwind config merge

`tailwind.config.js` extends `theme.extend` with MAVEN's `cream`, `ink`, `navy`, `terra` palettes and three `keyframes`. **If you already have a `tailwind.config.js`, merge these `extend` keys into your existing config** rather than replacing the file.

Important: set `content` to include MAVEN's JSX files:

```js
content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html']
```

## 4. Import the root CSS

In your app entry (e.g. `src/index.js`), ensure `index.css` is imported once. Don't import `prose.css` or `Maven.css` from the entry — they're imported by `Maven.js` itself.

```js
import './index.css';
```

## 5. Use MAVEN

```jsx
import Maven from './components/Maven';

function App() {
  return (
    <div style={{ height: '100vh', overflow: 'hidden' }}>
      <Maven onClose={() => console.log('user clicked close')} />
    </div>
  );
}
```

That's it. The panel floats top-right by default, has history/dock-left/fullscreen controls in the header, and shows a welcome screen until the user sends a message.

## 6. Swap in a real backend

Replace `mockService.js`. Keep the two function signatures:

```js
export function pickPlan(text): Array<{ label, tool?, delay }>
export function pickAnswer(text): string (safe HTML)
```

For true streaming from an LLM endpoint, convert `Maven.js`'s submit flow:
- Replace the `for (const step of plan)` loop with reads from a Server-Sent Events stream where each event adds a reasoning step.
- Replace the `while (i < fullAnswer.length)` char-streaming with chunk appends from the same stream.
- Keep `abortRef.current` as the abort flag; check it between reads.

## 7. MUI 6.2.1 / @mui/joy — why I didn't use them

Your `package.json` lists `@mui/material`, `@mui/joy`, `@mui/icons-material`, etc. MAVEN's design is *highly custom* — the composer, reasoning card, autocomplete dropdown, and message bubbles all sit outside what MUI's default components give you, and forcing them into `Button`/`Paper`/`Popper` would add weight without matching the intended look.

If you want to gradually move MAVEN toward MUI primitives, the natural swap points are:
- `icon-btn` (header + composer) → `IconButton` with a custom `sx`
- `HistoryPane` → `Drawer` with `variant="persistent"`
- `Autocomplete` dropdown → MUI's `Popper` + `MenuList` (loses the match-highlight styling — you'd need to reimplement)

I'd leave it alone until there's a concrete reason.

## 8. Known caveats I want you to see

- **Route-level integration**: MAVEN is written to float inside a full-height container. If you drop it into a page with its own scroll, wrap it in a fixed-position container or give its parent `height: 100vh; overflow: hidden`.
- **MobX integration**: If you want MAVEN's session list + messages in a MobX store, wrap `Maven.js` in `observer()` from `mobx-react` and swap the `useState` calls for store reads/writes. The component doesn't assume MobX; it's just local state today.
- **Abort during `ActionBar` regenerate**: clicking regenerate while another stream is in-flight will stack requests. If that matters, guard `onRegenerate` with `if (streaming) return`.
- **ThinkingIndicator in Strict Mode**: the `setInterval` inside the `useEffect` is cleaned up correctly, but `React.StrictMode` will double-invoke `useEffect` in development — you may see the rotation tick twice as fast for the first render. Production build is fine.
- **HTML answers are trusted**: `pickAnswer()` returns HTML that I render with `dangerouslySetInnerHTML`. Currently safe because it's a hard-coded constant. **When you swap in a real LLM, sanitize with `dompurify` before setting.**
