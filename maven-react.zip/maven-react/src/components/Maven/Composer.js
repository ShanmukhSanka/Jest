import React, { useCallback, useEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { Paperclip, Send, Square } from 'lucide-react';
import Autocomplete, { buildSections } from './Autocomplete';

/**
 * Composer: the textarea + send/stop button + autocomplete dropdown.
 *
 * Parent supplies the current `streaming` flag and callbacks:
 *   onSend(text):  user pressed Enter or clicked Send
 *   onStop():      user hit the stop button while streaming
 *
 * Keyboard:
 *   Enter        -> send (or pick the active ac item if the menu is open)
 *   Shift+Enter  -> newline
 *   ArrowUp/Down -> navigate autocomplete
 *   Tab          -> insert the active ac item into the input (no send)
 *   Escape       -> close autocomplete
 */
const Composer = ({ streaming, onSend, onStop, sessions }) => {
  const [value, setValue] = useState('');
  const [acOpen, setAcOpen] = useState(false);
  const [activeIdx, setActiveIdx] = useState(-1);
  const textareaRef = useRef(null);

  const hasText = value.trim().length > 0;

  // Auto-resize the textarea as the user types
  const autoGrow = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 128) + 'px';
  }, []);
  useEffect(() => { autoGrow(); }, [value, autoGrow]);

  // Flat list of selectable items (for keyboard nav)
  const flatItems = React.useMemo(
    () => buildSections(value, sessions).flatMap((sec) => sec.items),
    [value, sessions]
  );

  const openAc  = () => setAcOpen(true);
  const closeAc = () => { setAcOpen(false); setActiveIdx(-1); };

  const pickItem = (item) => {
    closeAc();
    if (item.sendOnSelect) {
      setValue('');
      onSend(item.text);
    } else {
      setValue(item.text);
      requestAnimationFrame(() => textareaRef.current?.focus());
    }
  };

  const send = () => {
    if (streaming) { onStop(); return; }
    const text = value.trim();
    if (!text) return;
    setValue('');
    closeAc();
    onSend(text);
  };

  const handleKey = (e) => {
    // Autocomplete navigation
    if (acOpen && flatItems.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setActiveIdx((i) => (i + 1) % flatItems.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setActiveIdx((i) => (i <= 0 ? flatItems.length - 1 : i - 1));
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        closeAc();
        return;
      }
      if (e.key === 'Tab' && activeIdx >= 0) {
        e.preventDefault();
        const item = flatItems[activeIdx];
        if (item) {
          setValue(item.text);
          closeAc();
        }
        return;
      }
      if (e.key === 'Enter' && !e.shiftKey && activeIdx >= 0) {
        e.preventDefault();
        pickItem(flatItems[activeIdx]);
        return;
      }
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      closeAc();
      send();
    }
  };

  // Close autocomplete on outside click
  useEffect(() => {
    const onDocClick = (e) => {
      const root = textareaRef.current?.closest('.ac-wrap');
      if (!root) return;
      if (!root.contains(e.target)) closeAc();
    };
    document.addEventListener('click', onDocClick);
    return () => document.removeEventListener('click', onDocClick);
  }, []);

  return (
    <div className="px-4 pb-4 pt-2 shrink-0">
      <div className="ac-wrap">
        <Autocomplete
          value={value}
          sessions={sessions}
          activeIdx={activeIdx}
          setActiveIdx={setActiveIdx}
          onPick={pickItem}
          open={acOpen && !streaming}
        />

        <div className="composer-shell">
          <div className="flex items-center justify-between px-3 pt-2">
            <div className="flex items-center gap-1">
              <button
                className="icon-btn !w-7 !h-7 tip"
                data-tip="Attach"
                aria-label="Attach"
                type="button"
              >
                <Paperclip size={14} strokeWidth={1.8} />
              </button>
            </div>
            <div className="font-mono text-[10px] text-ink-400">⌘ + ↵</div>
          </div>

          <div className="flex items-end gap-2 px-3 pt-2.5 pb-3">
            <textarea
              ref={textareaRef}
              rows={1}
              placeholder="Ask Maven anything…"
              className="flex-1 bg-transparent outline-none resize-none text-[14.5px] text-ink-900 placeholder:text-ink-400 max-h-32 thin-scroll py-1 leading-relaxed"
              value={value}
              onChange={(e) => {
                setValue(e.target.value);
                if (!streaming) setAcOpen(true);
              }}
              onKeyDown={handleKey}
              onFocus={() => { if (!streaming) openAc(); }}
              onClick={() => { if (!streaming) openAc(); }}
            />
            <button
              className={clsx('send-btn', streaming && 'streaming')}
              onClick={send}
              disabled={!streaming && !hasText}
              aria-label={streaming ? 'Stop' : 'Send'}
              type="button"
            >
              {streaming
                ? <Square size={12} fill="currentColor" strokeWidth={0} />
                : <Send size={15} strokeWidth={2.2} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Composer;
