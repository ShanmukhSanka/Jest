import React, { useEffect, useRef, useState, useImperativeHandle, forwardRef } from 'react';
import './thinking-indicator.css';

/**
 * 25 themed loading micro-animations. Each variant contributes a label and a
 * small cluster of divs with pure-CSS keyframes defined in thinking-indicator.css.
 *
 * Usage:
 *   <ThinkingIndicator active={isLoading} rotateMs={3500} />
 *
 * Or imperatively (matches the original class API):
 *   const ref = useRef();
 *   <ThinkingIndicator ref={ref} />
 *   ref.current.start(); ref.current.stop(); ref.current.next();
 */

export const TI_VARIANTS = [
  { key: 'cook',    label: 'Cooking',       render: () => <div className="ti-cook"><div className="ti-cook__pot" /><div className="ti-cook__steam" /><div className="ti-cook__steam" /><div className="ti-cook__steam" /></div> },
  { key: 'exp',     label: 'Experimenting', render: () => <div className="ti-exp"><div className="ti-exp__tube ti-exp__tube--a"><div className="ti-exp__liquid" /><div className="ti-exp__bubble" /></div><div className="ti-exp__tube ti-exp__tube--b"><div className="ti-exp__liquid" /><div className="ti-exp__bubble" /></div></div> },
  { key: 'swim',    label: 'Swimming',      render: () => <div className="ti-swim"><div className="ti-swim__wave" /><div className="ti-swim__body" /><div className="ti-swim__arm" /></div> },
  { key: 'dive',    label: 'Diving',        render: () => <div className="ti-dive"><div className="ti-dive__figure" /><div className="ti-dive__water" /><div className="ti-dive__ripple" /><div className="ti-dive__ripple ti-dive__ripple--b" /></div> },
  { key: 'jump',    label: 'Jumping',       render: () => <div className="ti-jump"><div className="ti-jump__shadow" /><div className="ti-jump__shape" /></div> },
  { key: 'run',     label: 'Running',       render: () => <div className="ti-run"><div className="ti-run__body" /><div className="ti-run__leg ti-run__leg--a" /><div className="ti-run__leg ti-run__leg--b" /><div className="ti-run__line" /><div className="ti-run__line" /></div> },
  { key: 'cycle',   label: 'Cycling',       render: () => <div className="ti-cycle"><div className="ti-cycle__wheel ti-cycle__wheel--a" /><div className="ti-cycle__wheel ti-cycle__wheel--b" /><div className="ti-cycle__frame" /><div className="ti-cycle__seat" /></div> },
  { key: 'dance',   label: 'Dancing',       render: () => <div className="ti-dance"><div className="ti-dance__floor" /><div className="ti-dance__spot" /><div className="ti-dance__figure" /><div className="ti-dance__arm ti-dance__arm--l" /><div className="ti-dance__arm ti-dance__arm--r" /></div> },
  { key: 'think',   label: 'Thinking',      render: () => <div className="ti-think"><div className="ti-think__head" /><div className="ti-think__bubble" /><div className="ti-think__bubble" /><div className="ti-think__bubble" /></div> },
  { key: 'brew',    label: 'Brewing',       render: () => <div className="ti-brew"><div className="ti-brew__swirl" /><div className="ti-brew__cup"><div className="ti-brew__surface" /></div></div> },
  { key: 'paint',   label: 'Painting',      render: () => <div className="ti-paint"><div className="ti-paint__canvas"><div className="ti-paint__stroke" /></div><div className="ti-paint__brush" /></div> },
  { key: 'write',   label: 'Writing',       render: () => <div className="ti-write"><div className="ti-write__line" /><div className="ti-write__ink" /><div className="ti-write__pen" /></div> },
  { key: 'dig',     label: 'Digging',       render: () => <div className="ti-dig"><div className="ti-dig__ground" /><div className="ti-dig__shovel" /><div className="ti-dig__dirt" /><div className="ti-dig__dirt" /><div className="ti-dig__dirt" /></div> },
  { key: 'climb',   label: 'Climbing',      render: () => <div className="ti-climb"><div className="ti-climb__rail ti-climb__rail--a" /><div className="ti-climb__rail ti-climb__rail--b" /><div className="ti-climb__rung" /><div className="ti-climb__rung" /><div className="ti-climb__rung" /><div className="ti-climb__figure" /></div> },
  { key: 'juggle',  label: 'Juggling',      render: () => <div className="ti-juggle"><div className="ti-juggle__ball ti-juggle__ball--a" /><div className="ti-juggle__ball ti-juggle__ball--b" /><div className="ti-juggle__ball ti-juggle__ball--c" /><div className="ti-juggle__hands" /></div> },
  { key: 'surf',    label: 'Surfing',       render: () => <div className="ti-surf"><div className="ti-surf__wave" /><div className="ti-surf__board" /><div className="ti-surf__figure" /></div> },
  { key: 'skate',   label: 'Skating',       render: () => <div className="ti-skate"><div className="ti-skate__ice" /><div className="ti-skate__blur" /><div className="ti-skate__figure" /></div> },
  { key: 'fly',     label: 'Flying',        render: () => <div className="ti-fly"><div className="ti-fly__trail" /><div className="ti-fly__bird"><div className="ti-fly__bird__body" /></div></div> },
  { key: 'read',    label: 'Reading',       render: () => <div className="ti-read"><div className="ti-read__book"><div className="ti-read__page" /></div></div> },
  { key: 'draw',    label: 'Drawing',       render: () => <div className="ti-draw"><div className="ti-draw__pad" /><div className="ti-draw__scribble" /><div className="ti-draw__pencil" /></div> },
  { key: 'meas',    label: 'Measuring',     render: () => <div className="ti-meas"><div className="ti-meas__bar" /><div className="ti-meas__caliper" /></div> },
  { key: 'polish',  label: 'Polishing',     render: () => <div className="ti-polish"><div className="ti-polish__surface"><div className="ti-polish__shine" /></div><div className="ti-polish__cloth" /></div> },
  { key: 'garden',  label: 'Gardening',     render: () => <div className="ti-garden"><div className="ti-garden__soil" /><div className="ti-garden__stem" /><div className="ti-garden__leaf ti-garden__leaf--a" /><div className="ti-garden__leaf ti-garden__leaf--b" /><div className="ti-garden__bud" /></div> },
  { key: 'hammer',  label: 'Hammering',     render: () => <div className="ti-hammer"><div className="ti-hammer__nail" /><div className="ti-hammer__spark ti-hammer__spark--a" /><div className="ti-hammer__spark ti-hammer__spark--b" /><div className="ti-hammer__tool" /></div> },
  { key: 'mix',     label: 'Mixing',        render: () => <div className="ti-mix"><div className="ti-mix__bowl" /><div className="ti-mix__whisk" /></div> },
];

// Pick a random variant index that isn't the same as `lastIdx`.
const pickNext = (lastIdx) => {
  if (TI_VARIANTS.length <= 1) return 0;
  let i = Math.floor(Math.random() * TI_VARIANTS.length);
  if (i === lastIdx) i = (i + 1) % TI_VARIANTS.length;
  return i;
};

const ThinkingIndicator = forwardRef(function ThinkingIndicator(
  { active = true, rotateMs = 3500, className, style },
  ref
) {
  const [idx, setIdx] = useState(() => Math.floor(Math.random() * TI_VARIANTS.length));
  const [fading, setFading] = useState(false);
  const intervalRef = useRef(null);

  const rotate = () => {
    setFading(true);
    setTimeout(() => {
      setIdx((prev) => pickNext(prev));
      setFading(false);
    }, 180);
  };

  // Auto-rotation while active
  useEffect(() => {
    if (!active) return undefined;
    intervalRef.current = setInterval(rotate, rotateMs);
    return () => clearInterval(intervalRef.current);
  }, [active, rotateMs]);

  // Imperative API for code that wants to drive it manually
  useImperativeHandle(
    ref,
    () => ({
      start: () => {
        if (intervalRef.current) return;
        intervalRef.current = setInterval(rotate, rotateMs);
      },
      stop: () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      },
      next: rotate,
    }),
    [rotateMs]
  );

  if (!active) return null;
  const variant = TI_VARIANTS[idx];

  return (
    <div className={`ti-root ${className || ''}`} style={style}>
      <div className={`ti-stage ${fading ? 'fading' : ''}`}>{variant.render()}</div>
      <span className="ti-label">{variant.label}</span>
    </div>
  );
});

export default ThinkingIndicator;
