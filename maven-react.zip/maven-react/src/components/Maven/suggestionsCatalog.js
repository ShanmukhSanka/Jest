/**
 * Static catalogs that drive the autocomplete dropdown and welcome tiles.
 * When the real backend can supply these, swap these exports for fetched data.
 */

export const PROMPTS = [
  { q: "Summarize last night's ETL failures across EDL" },
  { q: 'Show me jobs that ran longer than usual today' },
  { q: 'Explain the claims_ingest_hourly pipeline' },
  { q: "Which tables haven't been updated in the last 24 hours?" },
  { q: 'Compare schema between raw.claims and edl.fact_claims' },
  { q: 'Who owns the member_360_build job?' },
  { q: 'List all jobs with schema drift this week' },
  { q: 'Walk me through the Maven tool capabilities' },
  { q: 'Draft a Python script to reconcile the fact_claims table' },
  { q: 'Diagnose why risk_score_export is failing' },
  { q: 'What SLAs are at risk this week?' },
  { q: 'How do I request access to EDLUIOPS?' },
];

// `icon` names map to lucide-react icons used by Autocomplete.js
export const ACTIONS = [
  { q: 'Upload CSV to orchestrator_config',                  icon: 'Upload' },
  { q: 'Upload CSV to job_registry',                         icon: 'Upload' },
  { q: 'Download CSV template for orchestrator_config',      icon: 'Download' },
  { q: 'Rerun failed jobs from last night',                  icon: 'Play' },
  { q: 'Open a Jira ticket for IAM rotation',                icon: 'Ticket' },
  { q: 'Post run summary to #data-ops Teams channel',        icon: 'Send' },
  { q: 'Delete stale records from dq_rules',                 icon: 'Trash2' },
];

export const SLASHES = [
  { cmd: '/rerun',   desc: 'Rerun a failed or stuck job' },
  { cmd: '/explain', desc: 'Explain a job, table, or column' },
  { cmd: '/diff',    desc: 'Compare two schemas or runs' },
  { cmd: '/lineage', desc: 'Show upstream / downstream lineage' },
  { cmd: '/owners',  desc: 'Find owners of a table or job' },
  { cmd: '/new',     desc: 'Start a fresh session' },
];

// The 4 cards shown on the welcome screen (a curated subset of PROMPTS)
export const WELCOME_CARDS = [
  { label: 'Capabilities', short: 'What tools can you run?',            q: 'What are your tool capabilities?',                          icon: 'Wrench' },
  { label: 'Diagnose',     short: "Summarize last night's ETL failures.", q: "Summarize last night's ETL failures across EDL.",        icon: 'LineChart' },
  { label: 'Code',         short: 'Reconcile the fact_claims table.',    q: 'Draft a Python script to reconcile the fact_claims table.', icon: 'Code2' },
  { label: 'Action',       short: 'Upload CSV to orchestrator_config.',  q: 'Upload a CSV to the orchestrator_config table.',           icon: 'Upload' },
];

// Seed sessions for the history pane; replace with real data from your store
export const SEED_SESSIONS = [
  { id: 's1', title: 'who is the president of USA?',      time: '11m ago' },
  { id: 's2', title: 'which LLM are you built on',        time: '12m ago' },
  { id: 's3', title: 'when is optimus prime releasing?',  time: '15m ago' },
  { id: 's4', title: 'write me a python code',            time: '1h ago'  },
  { id: 's5', title: 'what is your capacity?',            time: '1h ago'  },
  { id: 's6', title: 'New session',                       time: 'just now', active: true },
];
