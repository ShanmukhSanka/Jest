import React, { useEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { ChevronDown, Check } from 'lucide-react';
import ThinkingIndicator from './ThinkingIndicator';
import ReasoningStep from './ReasoningStep';

/**
 * Three phases:
 *   - 'thinking':  shows the rotating ThinkingIndicator + live timer + streaming steps
 *   - 'done':      shows checkmark + "DONE {time}s" + step list, collapsed after delay
 *   - 'aborted':   indicator hidden, shows frozen timer
 *
 * Props:
 *   steps: Array<{ id, label, tool?, done }>
 *   elapsedMs: number (ticked by Maven.js)
 *   phase: 'thinking' | 'done' | 'aborted'
 */
const ReasoningCard = ({ steps, elapsedMs, phase }) => {
  const [open, setOpen] = useState(true);
  const autoCollapsedRef = useRef(false);

  // Auto-collapse shortly after reaching 'done'
  useEffect(() => {
    if (phase === 'done' && !autoCollapsedRef.current) {
      autoCollapsedRef.current = true;
      const t = setTimeout(() => setOpen(false), 500);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [phase]);

  const seconds = (elapsedMs / 1000).toFixed(1);

  return (
    <div className="reasoning mb-3">
      <button
        type="button"
        className="reasoning-header w-full"
        onClick={() => setOpen((o) => !o)}
      >
        <div className="flex items-center gap-2 min-w-0">
          {phase === 'thinking' ? (
            <ThinkingIndicator active rotateMs={3500} />
          ) : (
            <>
              <Check size={13} strokeWidth={2.2} className="text-ink-500" />
              <span className="font-mono text-[10.5px] tracking-[0.12em] uppercase text-ink-500">
                Done
              </span>
            </>
          )}
          <span className="text-[10.5px] text-ink-400 font-mono">{seconds}s</span>
        </div>
        <ChevronDown
          size={12}
          className={clsx(
            'text-ink-400 transition-transform',
            !open && '-rotate-90'
          )}
        />
      </button>

      {open && (
        <div className="reasoning-body">
          {steps.map((s) => (
            <ReasoningStep
              key={s.id}
              text={s.label}
              tool={s.tool}
              done={s.done}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ReasoningCard;
