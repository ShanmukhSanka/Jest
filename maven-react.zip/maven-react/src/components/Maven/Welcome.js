import React from 'react';
import MavenLogo from './MavenLogo';
import SuggestionCard from './SuggestionCard';
import { WELCOME_CARDS } from './suggestionsCatalog';

const Welcome = ({ userName = 'Shanmukh', onPick }) => (
  <div className="min-h-full flex flex-col items-center justify-center text-center py-4">
    <div className="mb-6">
      <MavenLogo.Tile size={56} />
    </div>
    <div className="font-mono text-[10px] tracking-[0.2em] text-ink-500 uppercase mb-3">
      Hi, {userName}
    </div>
    <h1 className="hero-title text-[38px] leading-[1.1] mb-2">
      How can I <em>help</em>?
    </h1>
    <p className="text-[13px] text-ink-600 max-w-[320px] mb-7 mt-1 leading-relaxed">
      Maven is an agentic copilot for the Enterprise Data Platform. Ask a question,
      delegate a task, or connect a tool.
    </p>
    <div className="grid grid-cols-2 gap-2.5 w-full max-w-[420px]">
      {WELCOME_CARDS.map((c) => (
        <SuggestionCard
          key={c.label}
          label={c.label}
          short={c.short}
          iconName={c.icon}
          onClick={() => onPick?.(c.q)}
        />
      ))}
    </div>
  </div>
);

export default Welcome;
