import React, { useState } from 'react';
import clsx from 'clsx';
import { motion } from 'framer-motion';
import { Copy, ThumbsUp, ThumbsDown, RotateCcw, Check } from 'lucide-react';

const ActionBar = ({ text, onRegenerate }) => {
  const [copied, setCopied] = useState(false);
  const [vote, setVote] = useState(null); // 'up' | 'down' | null

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // fallback for older browsers
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); } catch { /* no-op */ }
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  return (
    <motion.div
      className="flex items-center gap-0.5 mt-3"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <button
        className={clsx('act-btn tip', copied && 'good')}
        data-tip={copied ? 'Copied ✓' : 'Copy'}
        onClick={copy}
        aria-label="Copy response"
      >
        {copied
          ? <Check size={13} strokeWidth={2} />
          : <Copy size={13} strokeWidth={1.8} />}
      </button>
      <button
        className={clsx('act-btn tip', vote === 'up' && 'good')}
        data-tip="Good response"
        onClick={() => setVote(vote === 'up' ? null : 'up')}
        aria-label="Good response"
      >
        <ThumbsUp size={13} strokeWidth={1.8} />
      </button>
      <button
        className={clsx('act-btn tip', vote === 'down' && 'bad')}
        data-tip="Bad response"
        onClick={() => setVote(vote === 'down' ? null : 'down')}
        aria-label="Bad response"
      >
        <ThumbsDown size={13} strokeWidth={1.8} />
      </button>
      <button
        className="act-btn tip"
        data-tip="Regenerate"
        onClick={onRegenerate}
        aria-label="Regenerate"
      >
        <RotateCcw size={13} strokeWidth={1.8} />
      </button>
    </motion.div>
  );
};

export default ActionBar;
