import React from 'react';
import * as Icons from 'lucide-react';

/**
 * A single suggestion card, e.g. "CAPABILITIES — What tools can you run?".
 * `icon` is a lucide-react icon name (string).
 */
const SuggestionCard = ({ label, short, iconName, onClick }) => {
  const Icon = Icons[iconName] || Icons.Sparkles;
  return (
    <button
      type="button"
      className="suggest-card w-full"
      onClick={onClick}
    >
      <div className="flex items-center gap-2 mb-1.5">
        <Icon size={13} strokeWidth={1.8} className="text-navy-500" />
        <span className="lbl">{label}</span>
      </div>
      <div className="text-[13.5px] text-ink-800 leading-snug">{short}</div>
    </button>
  );
};

export default SuggestionCard;
