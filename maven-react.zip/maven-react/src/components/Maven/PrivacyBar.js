import React from 'react';
import { ShieldCheck } from 'lucide-react';

const PrivacyBar = () => (
  <div className="flex items-start gap-2 px-4 py-2 border-b border-cream-200 bg-cream-50 shrink-0">
    <ShieldCheck size={13} className="mt-0.5 shrink-0 text-navy-500" strokeWidth={2} />
    <div className="text-[11px] text-ink-600 leading-relaxed">
      Confidential data auto-redacted. All agent actions require your confirmation.
    </div>
  </div>
);

export default PrivacyBar;
