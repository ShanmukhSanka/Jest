import React from 'react';
import clsx from 'clsx';
import { Search } from 'lucide-react';

const HistoryPane = ({ sessions, onPick, contextUsed = 2.4, contextTotal = 128 }) => {
  const pct = Math.min(100, Math.max(2, Math.round((contextUsed / contextTotal) * 100)));

  return (
    <aside
      className="w-[200px] border-r border-cream-200 shrink-0 flex flex-col"
      style={{ background: 'var(--cream-50)' }}
    >
      <div className="px-3 py-3 flex items-center justify-between shrink-0">
        <span className="font-mono text-[10px] text-ink-500 tracking-[0.15em] uppercase">
          Sessions
        </span>
        <button className="icon-btn !w-6 !h-6 tip" data-tip="Search" aria-label="Search">
          <Search size={12} strokeWidth={2} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto thin-scroll px-2 pb-2 space-y-0.5">
        {sessions.map((s) => (
          <div
            key={s.id}
            className={clsx('history-item animate-fade-up', s.active && 'active')}
            onClick={() => onPick?.(s.id)}
          >
            <div className="text-[12.5px] text-ink-800 leading-snug history-item-title">
              {s.title}
            </div>
            <div className="text-[10px] font-mono text-ink-500 mt-0.5">{s.time}</div>
          </div>
        ))}
      </div>

      <div className="px-3 py-2.5 border-t border-cream-200 shrink-0">
        <div className="flex justify-between font-mono text-[10px] text-ink-500">
          <span>Context</span>
          <span className="text-navy-600">
            {contextUsed}k / {contextTotal}k
          </span>
        </div>
        <div className="mt-1 h-1 rounded-full bg-cream-200 overflow-hidden">
          <div className="h-full bg-navy-400" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </aside>
  );
};

export default HistoryPane;
