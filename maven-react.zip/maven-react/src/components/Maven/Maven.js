import React, { useCallback, useEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { motion, AnimatePresence } from 'framer-motion';

import Header        from './Header';
import PrivacyBar    from './PrivacyBar';
import HistoryPane   from './HistoryPane';
import MessageList   from './MessageList';
import Welcome       from './Welcome';
import UserMessage   from './UserMessage';
import AiMessage     from './AiMessage';
import ReasoningCard from './ReasoningCard';
import ActionBar     from './ActionBar';
import Composer      from './Composer';

import { pickPlan, pickAnswer, stripHtml } from './mockService';
import { SEED_SESSIONS }                   from './suggestionsCatalog';

import './Maven.css';
import '../../styles/prose.css';

const nowStr = () =>
  new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Maven — agentic copilot chat panel.
 *
 * High-level flow for submitMessage():
 *   1. Append user message.
 *   2. Create an AI message with phase=thinking, empty steps, empty answer.
 *   3. Stream reasoning steps with delays.
 *   4. Flip phase to 'done' (triggers TI stop + auto-collapse).
 *   5. Type out the answer HTML character-by-character into state.
 *   6. If aborted at any step, mark aborted=true and exit early.
 */
const Maven = ({ onClose }) => {
  // -------- chat state --------
  const [messages, setMessages] = useState([]); // { kind: 'user'|'ai', ... }
  const [streaming, setStreaming] = useState(false);
  const [sessions, setSessions] = useState(SEED_SESSIONS);

  // -------- UI toggles --------
  const [historyOpen, setHistoryOpen] = useState(false);
  const [fullscreen, setFullscreen]   = useState(false);
  const [dockedRight, setDockedRight] = useState(true);

  // Mutable abort signal; not state because we don't want re-renders
  const abortRef = useRef(false);

  const updateMessage = useCallback((id, updater) => {
    setMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updater(m) } : m))
    );
  }, []);

  // ---------------------------------------------------------------
  // The main submit flow
  // ---------------------------------------------------------------
  const submitMessage = useCallback(
    async (text, { skipUserEcho = false } = {}) => {
      if (!skipUserEcho) {
        setMessages((prev) => [
          ...prev,
          { id: `u-${Date.now()}`, kind: 'user', text, time: nowStr() },
        ]);
      }

      const aiId = `a-${Date.now()}`;
      const plan = pickPlan(text);
      const startAt = performance.now();

      setMessages((prev) => [
        ...prev,
        {
          id: aiId,
          kind: 'ai',
          time: nowStr(),
          phase: 'thinking',
          steps: [],
          elapsedMs: 0,
          answer: '',
          aborted: false,
          fullAnswer: '',
          sourceText: text,
        },
      ]);

      setStreaming(true);
      abortRef.current = false;

      // Timer tick while we're in the thinking phase
      let timerId = setInterval(() => {
        updateMessage(aiId, () => ({ elapsedMs: performance.now() - startAt }));
      }, 100);

      // Stream reasoning steps
      for (let i = 0; i < plan.length; i++) {
        if (abortRef.current) break;
        const step = plan[i];
        const sid = `${aiId}-s${i}`;
        updateMessage(aiId, (m) => ({
          steps: [...m.steps, { id: sid, label: step.label, tool: step.tool, done: false }],
        }));
        await sleep(step.delay);
        updateMessage(aiId, (m) => ({
          steps: m.steps.map((s) => (s.id === sid ? { ...s, done: true } : s)),
        }));
      }

      clearInterval(timerId);
      timerId = null;

      // Aborted during thinking?
      if (abortRef.current) {
        updateMessage(aiId, () => ({ phase: 'aborted', aborted: true }));
        setStreaming(false);
        return;
      }

      // Mark thinking done (ThinkingIndicator will stop, card will auto-collapse)
      updateMessage(aiId, () => ({
        phase: 'done',
        elapsedMs: performance.now() - startAt,
      }));

      // ----- Answer streaming -----
      // We simulate char-by-char streaming by growing `answer` in state.
      // The AiMessage renders `answer` with dangerouslySetInnerHTML.
      const fullAnswer = pickAnswer(text);
      updateMessage(aiId, () => ({ fullAnswer }));

      // Truncate a slice back to a "safe" boundary — never render a partial
      // HTML tag. If an opening '<' has no matching '>' yet, cut before the '<'.
      const safeSlice = (s) => {
        const lastOpen  = s.lastIndexOf('<');
        const lastClose = s.lastIndexOf('>');
        if (lastOpen > lastClose) return s.slice(0, lastOpen);
        return s;
      };

      let i = 0;
      while (i < fullAnswer.length) {
        if (abortRef.current) break;
        const step = 2 + Math.floor(Math.random() * 3);
        i = Math.min(i + step, fullAnswer.length);
        const slice = safeSlice(fullAnswer.slice(0, i));
        updateMessage(aiId, () => ({ answer: slice }));
        await sleep(10 + Math.random() * 12);
      }
      // Final frame: always the full, unmolested answer
      if (!abortRef.current) {
        updateMessage(aiId, () => ({ answer: fullAnswer }));
      }

      if (abortRef.current) {
        updateMessage(aiId, () => ({ aborted: true }));
      }
      setStreaming(false);
    },
    [updateMessage]
  );

  const onStop = useCallback(() => { abortRef.current = true; }, []);

  const onRegenerate = useCallback(
    (aiMsgId) => {
      // find the AI message and its preceding user message
      setMessages((prev) => {
        const i = prev.findIndex((m) => m.id === aiMsgId);
        if (i < 0) return prev;
        const ai = prev[i];
        const trimmed = prev.slice(0, i);
        // find previous user msg
        const prevUser = [...trimmed].reverse().find((m) => m.kind === 'user');
        if (!prevUser) return prev;
        // remove the AI block we're regenerating
        setTimeout(() => submitMessage(prevUser.text, { skipUserEcho: true }), 0);
        return trimmed;
      });
    },
    [submitMessage]
  );

  // ---------------------------------------------------------------
  // Toggles
  // ---------------------------------------------------------------
  const newChat = () => {
    setMessages([]);
    abortRef.current = false;
    setStreaming(false);
  };
  const pickSession = (id) => {
    setSessions((prev) => prev.map((s) => ({ ...s, active: s.id === id })));
    // (In a real app this would load the session's messages from a store.)
  };

  // ---------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------
  return (
    <>
      {/* Backdrop with watermark — simulates the parent workspace */}
      <div className="absolute inset-0 pointer-events-none select-none flex flex-col items-center justify-center maven-backdrop">
        <div
          className="font-mono text-[10px] tracking-[0.3em] text-ink-400 uppercase mb-6"
          style={{ opacity: 0.5 }}
        >
          Workspace · Enterprise Data Platform
        </div>
        <div className="maven-watermark text-8xl italic">calm focus.</div>
      </div>

      {/* Floating dock */}
      <div
        className={clsx(
          'absolute top-5 bottom-5 w-[520px] maven-dock-transition z-10',
          dockedRight ? 'right-5' : 'left-5',
          fullscreen && '!inset-0 !w-auto'
        )}
      >
        <div
          className={clsx(
            'maven-panel rounded-2xl h-full flex flex-col overflow-hidden',
            fullscreen && 'maven-panel--fullscreen'
          )}
        >
          <Header
            historyOpen={historyOpen}
            fullscreen={fullscreen}
            onNewChat={newChat}
            onToggleHistory={() => setHistoryOpen((h) => !h)}
            onToggleDock={() => setDockedRight((r) => !r)}
            onToggleFullscreen={() => setFullscreen((f) => !f)}
            onClose={onClose}
          />

          <PrivacyBar />

          <div className="flex-1 flex min-h-0">
            {historyOpen && (
              <HistoryPane sessions={sessions} onPick={pickSession} />
            )}

            <main className="flex-1 flex flex-col min-w-0">
              <MessageList scrollKey={messages.length + (messages[messages.length - 1]?.answer?.length || 0)}>
                {messages.length === 0 && (
                  <Welcome userName="Shanmukh" onPick={submitMessage} />
                )}
                <AnimatePresence initial={false}>
                  {messages.map((m) => {
                    if (m.kind === 'user') {
                      return (
                        <UserMessage
                          key={m.id}
                          text={m.text}
                          time={m.time}
                          initials="SS"
                        />
                      );
                    }
                    // AI
                    const showReasoning = m.phase !== undefined && m.steps.length > 0;
                    const showActions   = m.phase === 'done' && m.answer.length === m.fullAnswer.length && !m.aborted;
                    return (
                      <AiMessage key={m.id} time={m.time} aborted={m.aborted}>
                        {showReasoning && (
                          <ReasoningCard
                            steps={m.steps}
                            elapsedMs={m.elapsedMs}
                            phase={m.phase}
                          />
                        )}
                        {m.answer && (
                          <div
                            className="prose-ai"
                            dangerouslySetInnerHTML={{ __html: m.answer }}
                          />
                        )}
                        {showActions && (
                          <ActionBar
                            text={stripHtml(m.fullAnswer)}
                            onRegenerate={() => onRegenerate(m.id)}
                          />
                        )}
                      </AiMessage>
                    );
                  })}
                </AnimatePresence>
              </MessageList>

              <Composer
                streaming={streaming}
                sessions={sessions}
                onSend={submitMessage}
                onStop={onStop}
              />
            </main>
          </div>
        </div>
      </div>
    </>
  );
};

export default Maven;
