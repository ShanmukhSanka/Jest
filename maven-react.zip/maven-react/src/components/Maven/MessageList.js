import React, { useEffect, useRef } from 'react';

const MessageList = ({ children, scrollKey }) => {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Stick to bottom on every new message/render
    el.scrollTop = el.scrollHeight;
  }, [scrollKey, children]);
  return (
    <div
      ref={ref}
      className="flex-1 overflow-y-auto thin-scroll px-5 pt-6 pb-2 space-y-4"
    >
      {children}
    </div>
  );
};

export default MessageList;
