import React from 'react';
import { motion } from 'framer-motion';
import { Square } from 'lucide-react';
import MavenLogo from './MavenLogo';

const AiMessage = ({ time, aborted, children }) => (
  <motion.div
    className="flex items-start gap-3"
    initial={{ opacity: 0, y: 6 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
  >
    <MavenLogo.Tile size={28} glyphSize={16} className="mt-0.5" />

    <div className="flex-1 min-w-0 max-w-[88%]">
      <div className="flex items-baseline gap-2 mb-1">
        <span className="font-serif text-[14px] font-medium text-ink-900">Maven</span>
        <span className="text-[10px] font-mono text-ink-400">{time}</span>
      </div>
      <div className="ai-content">
        {children}
        {aborted && (
          <div className="mt-2 text-[11.5px] text-navy-600 font-mono flex items-center gap-1.5">
            <Square size={10} fill="currentColor" strokeWidth={0} />
            Stopped by you
          </div>
        )}
      </div>
    </div>
  </motion.div>
);

export default AiMessage;
