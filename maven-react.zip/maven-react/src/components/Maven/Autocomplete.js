import React, { useMemo, useEffect, useRef } from 'react';
import clsx from 'clsx';
import * as Icons from 'lucide-react';
import { MessageSquare, Clock } from 'lucide-react';
import { PROMPTS, ACTIONS, SLASHES } from './suggestionsCatalog';

const MAX_STARTER_PROMPTS = 4;
const MAX_MATCH_PROMPTS   = 5;
const MAX_MATCH_ACTIONS   = 4;
const MAX_MATCH_RECENT    = 3;

const esc = (s) => String(s);

// Render a label with the matching substring wrapped in <span.ac-match>
const HighlightedLabel = ({ text, query }) => {
  if (!query) return <>{text}</>;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return <>{text}</>;
  return (
    <>
      {text.slice(0, idx)}
      <span className="ac-match">{text.slice(idx, idx + query.length)}</span>
      {text.slice(idx + query.length)}
    </>
  );
};

/**
 * Builds the list of sections to render, given the current composer value
 * and the recent-sessions list.  Shape matches the old vanilla dropdown
 * so the rest of the rendering code is a simple map.
 */
function buildSections(raw, sessions) {
  const q = raw.trim();
  const ql = q.toLowerCase();
  const sections = [];

  // -------- Slash-command palette (priority when input starts with /) --------
  if (q.startsWith('/')) {
    const filter = ql.slice(1);
    const matches = SLASHES.filter(
      (s) => !filter || s.cmd.slice(1).toLowerCase().startsWith(filter)
    );
    if (matches.length) {
      sections.push({
        title: 'Commands',
        items: matches.map((s) => ({
          kind: 'slash',
          cmd: s.cmd,
          desc: s.desc,
          text: s.cmd + ' ',
          sendOnSelect: false,
        })),
      });
    }
    return sections;
  }

  // -------- Empty composer: show starters + recent --------
  if (!ql) {
    sections.push({
      title: 'Starters',
      items: PROMPTS.slice(0, MAX_STARTER_PROMPTS).map((p) => ({
        kind: 'prompt',
        text: p.q,
        sendOnSelect: true,
      })),
    });
    const recent = sessions
      .filter((s) => s.title && s.title !== 'New session')
      .slice(0, MAX_MATCH_RECENT);
    if (recent.length) {
      sections.push({
        title: 'Recent',
        items: recent.map((r) => ({
          kind: 'recent',
          text: r.title,
          hint: r.time,
          sendOnSelect: true,
        })),
      });
    }
    return sections;
  }

  // -------- User is typing: filter actions + prompts + recent --------
  const matchActions = ACTIONS.filter((a) => a.q.toLowerCase().includes(ql)).slice(0, MAX_MATCH_ACTIONS);
  const matchPrompts = PROMPTS.filter((p) => p.q.toLowerCase().includes(ql)).slice(0, MAX_MATCH_PROMPTS);
  const matchRecent  = sessions
    .filter((s) => s.title && s.title !== 'New session' && s.title.toLowerCase().includes(ql))
    .slice(0, MAX_MATCH_RECENT);

  if (matchActions.length) {
    sections.push({
      title: 'Actions',
      items: matchActions.map((a) => ({
        kind: 'action',
        iconName: a.icon,
        text: a.q,
        hint: 'run',
        sendOnSelect: true,
      })),
    });
  }
  if (matchPrompts.length) {
    sections.push({
      title: 'Suggestions',
      items: matchPrompts.map((p) => ({
        kind: 'prompt',
        text: p.q,
        sendOnSelect: true,
      })),
    });
  }
  if (matchRecent.length) {
    sections.push({
      title: 'Recent',
      items: matchRecent.map((r) => ({
        kind: 'recent',
        text: r.title,
        hint: r.time,
        sendOnSelect: true,
      })),
    });
  }
  return sections;
}

const RenderIcon = ({ item }) => {
  if (item.kind === 'slash') {
    return <span className="ac-ico slash">/</span>;
  }
  if (item.kind === 'action') {
    const Ico = Icons[item.iconName] || Icons.Sparkles;
    return (
      <span className="ac-ico act">
        <Ico size={12} strokeWidth={1.8} />
      </span>
    );
  }
  if (item.kind === 'recent') {
    return (
      <span className="ac-ico rec">
        <Clock size={11} strokeWidth={2} />
      </span>
    );
  }
  // prompt
  return (
    <span className="ac-ico nav">
      <MessageSquare size={11} strokeWidth={2} />
    </span>
  );
};

const Autocomplete = ({
  value,
  sessions,
  activeIdx,
  setActiveIdx,
  onPick,
  open,
}) => {
  const sections = useMemo(() => buildSections(value, sessions), [value, sessions]);
  const flatItems = useMemo(
    () => sections.flatMap((sec) => sec.items),
    [sections]
  );
  const menuRef = useRef(null);

  // Expose the flat item list upward so Maven can drive keyboard nav
  useEffect(() => {
    if (typeof setActiveIdx === 'function') {
      // Reset active when items change. Parent holds the index; we just ping 0 on open, -1 on close.
      setActiveIdx(flatItems.length ? -1 : -1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flatItems.length]);

  // Scroll the active item into view
  useEffect(() => {
    if (!menuRef.current || activeIdx < 0) return;
    const el = menuRef.current.querySelector(`.ac-item[data-idx="${activeIdx}"]`);
    if (el) el.scrollIntoView({ block: 'nearest' });
  }, [activeIdx]);

  if (!open || !sections.length) return null;

  let running = 0;
  return (
    <div className="ac-menu" ref={menuRef}>
      {sections.map((sec, si) => (
        <React.Fragment key={sec.title}>
          {si > 0 && <div className="ac-sep" />}
          <div className="ac-section">{sec.title}</div>
          {sec.items.map((it) => {
            const idx = running++;
            const isActive = idx === activeIdx;
            return (
              <div
                key={idx}
                data-idx={idx}
                className={clsx('ac-item', isActive && 'ac-active')}
                onMouseEnter={() => setActiveIdx(idx)}
                onMouseDown={(e) => {
                  e.preventDefault(); // keep focus on the textarea
                  onPick(it);
                }}
              >
                <RenderIcon item={it} />
                {it.kind === 'slash' ? (
                  <div className="ac-text">
                    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontWeight: 500, color: 'var(--ink-900)' }}>
                      {it.cmd}
                    </span>{' '}
                    <span className="text-ink-500" style={{ fontSize: 12.5 }}>
                      — {esc(it.desc)}
                    </span>
                  </div>
                ) : (
                  <div className="ac-text">
                    <HighlightedLabel text={it.text} query={value.trim()} />
                  </div>
                )}
                <span className="ac-hint">
                  {it.hint || (it.sendOnSelect ? '↵' : '')}
                </span>
              </div>
            );
          })}
        </React.Fragment>
      ))}
    </div>
  );
};

export { buildSections };
export default Autocomplete;
