import React from 'react';
import { motion } from 'framer-motion';

const UserMessage = ({ text, time, initials = 'SS' }) => (
  <motion.div
    className="flex items-start gap-3 justify-end"
    initial={{ opacity: 0, y: 6 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
  >
    <div className="max-w-[82%] flex flex-col items-end">
      <div className="bubble-user">{text}</div>
      <div className="text-[10px] font-mono text-ink-400 mt-1 pr-1">{time}</div>
    </div>
    <div className="w-7 h-7 rounded-full bg-cream-200 border border-cream-300 flex items-center justify-center text-[10.5px] font-semibold text-ink-700 shrink-0 mt-1">
      {initials}
    </div>
  </motion.div>
);

export default UserMessage;
