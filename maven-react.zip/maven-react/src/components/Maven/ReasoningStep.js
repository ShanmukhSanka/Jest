import React from 'react';
import clsx from 'clsx';
import { motion } from 'framer-motion';
import { Wrench } from 'lucide-react';

const ReasoningStep = ({ text, tool, done }) => (
  <motion.div
    className={clsx('reasoning-step', done && 'done')}
    initial={{ opacity: 0, y: 6 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
  >
    <div>{text}</div>
    {tool && (
      <div className="tool-chip">
        <Wrench size={10} strokeWidth={2} />
        {tool}
      </div>
    )}
  </motion.div>
);

export default ReasoningStep;
