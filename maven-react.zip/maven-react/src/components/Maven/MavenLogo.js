import React from 'react';
import clsx from 'clsx';

/**
 * MavenLogo — the "M" mark.
 *
 * Use <MavenLogo.Tile /> for the logo on a navy rounded-square background
 * (header, AI avatar, welcome hero). Use <MavenLogo.Glyph /> for the bare
 * white strokes on any color you control yourself.
 */
const Glyph = ({ size = 22, stroke = '#FFFFFF', strokeWidth = 2.4, className }) => (
  <svg
    className={className}
    width={size}
    height={size}
    viewBox="0 0 32 32"
    aria-label="Maven"
    role="img"
  >
    <path
      d="M8 23 L8 9 L16 17 L24 9 L24 23"
      stroke={stroke}
      strokeWidth={strokeWidth}
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const Tile = ({ size = 36, glyphSize, className, ...rest }) => {
  const glyph = glyphSize ?? Math.round(size * 0.61);
  const stroke = Math.max(2, size / 15);
  return (
    <div
      className={clsx(
        'flex items-center justify-center shrink-0',
        size <= 28 ? 'rounded-md' : 'rounded-lg',
        className
      )}
      style={{ width: size, height: size, background: '#0F1E3D' }}
      {...rest}
    >
      <Glyph size={glyph} strokeWidth={stroke} />
    </div>
  );
};

const MavenLogo = { Glyph, Tile };
export default MavenLogo;
