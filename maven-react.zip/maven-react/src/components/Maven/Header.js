import React from 'react';
import clsx from 'clsx';
import { Plus, History, PanelRight, Maximize2, X } from 'lucide-react';
import MavenLogo from './MavenLogo';

const Header = ({
  historyOpen,
  fullscreen,
  onNewChat,
  onToggleHistory,
  onToggleDock,
  onToggleFullscreen,
  onClose,
}) => (
  <div className="flex items-center justify-between px-4 py-3 border-b border-cream-200 shrink-0">
    <div className="flex items-center gap-2.5">
      <MavenLogo.Tile size={36} />
      <span className="font-serif text-[20px] font-medium text-ink-900 tracking-tight leading-none">
        Maven
      </span>
    </div>

    <div className="flex items-center gap-0.5">
      <button className="icon-btn tip" data-tip="New chat" onClick={onNewChat} aria-label="New chat">
        <Plus size={16} strokeWidth={1.8} />
      </button>
      <button
        className={clsx('icon-btn tip', historyOpen && 'active')}
        data-tip="History"
        onClick={onToggleHistory}
        aria-label="History"
      >
        <History size={16} strokeWidth={1.8} />
      </button>
      <button className="icon-btn tip" data-tip="Dock left/right" onClick={onToggleDock} aria-label="Dock">
        <PanelRight size={16} strokeWidth={1.8} />
      </button>
      <button
        className={clsx('icon-btn tip', fullscreen && 'active')}
        data-tip="Fullscreen"
        onClick={onToggleFullscreen}
        aria-label="Fullscreen"
      >
        <Maximize2 size={16} strokeWidth={1.8} />
      </button>
      <button className="icon-btn tip" data-tip="Close" onClick={onClose} aria-label="Close">
        <X size={16} strokeWidth={1.8} />
      </button>
    </div>
  </div>
);

export default Header;
