/**
 * Mock agent service. Returns a plan of reasoning steps and an HTML answer
 * for a given user message. Swap the internals for a real streaming endpoint
 * when the backend is ready; the shape of the return value is what
 * Maven.js consumes.
 *
 *   plan:   Array<{ label, tool?, delay }>
 *   answer: string (safe HTML — rendered with dangerouslySetInnerHTML)
 */

const escapeHtml = (s) =>
  String(s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );

// -------------------- Reasoning plans --------------------

export function pickPlan(text) {
  const q = text.toLowerCase();

  if (q.includes('capabilit') || q.includes('tool')) {
    return [
      { label: 'Parsing intent: capability inquiry', delay: 320 },
      { label: 'Reading registered tool manifest', tool: 'tools.list_manifest', delay: 480 },
      { label: 'Filtering by user permissions (EDLDEVOPS · EDLUIOPS)', delay: 380 },
      { label: 'Composing response', delay: 300 },
    ];
  }
  if (q.includes('etl') || q.includes('fail') || q.includes('diagnose') || q.includes('summariz')) {
    return [
      { label: 'Parsing intent: operations summary', delay: 300 },
      { label: 'Querying run_log for last 24h', tool: 'edl.query_runs', delay: 520 },
      { label: 'Ranking by error severity', delay: 360 },
      { label: 'Cross-referencing PagerDuty alerts', tool: 'pagerduty.fetch', delay: 460 },
      { label: 'Drafting summary', delay: 300 },
    ];
  }
  if (q.includes('python') || q.includes('code') || q.includes('script') || q.includes('reconcile')) {
    return [
      { label: 'Interpreting coding request', delay: 300 },
      { label: 'Loading fact_claims schema', tool: 'edl.describe_table', delay: 480 },
      { label: 'Drafting reconciliation logic', delay: 420 },
      { label: 'Verifying against style guide', delay: 340 },
    ];
  }
  if (q.includes('upload') || q.includes('csv')) {
    return [
      { label: 'Identifying target table', delay: 300 },
      { label: 'Fetching schema for orchestrator_config', tool: 'edl.describe_table', delay: 480 },
      { label: 'Preparing upload action', tool: 'edl.upload_csv', delay: 420 },
      { label: 'Awaiting confirmation', delay: 280 },
    ];
  }
  return [
    { label: 'Parsing request', delay: 320 },
    { label: 'Retrieving context', tool: 'context.recall', delay: 440 },
    { label: 'Composing answer', delay: 340 },
  ];
}

// -------------------- Answer HTML --------------------

export function pickAnswer(text) {
  const q = text.toLowerCase();

  if (q.includes('capabilit') || q.includes('tool')) {
    return `
<p>I'm Maven — an agentic copilot for the <strong>Enterprise Data Lake</strong>. With your <code>EDLDEVOPS</code> and <code>EDLUIOPS</code> access, here's what I can do:</p>
<h3>Query and view</h3>
<ul>
<li>Search metadata configurations in natural language</li>
<li>Insights on jobs, ETL steps, orchestrators, and lineage</li>
<li>Q&amp;A over AEDL and EDL framework documentation</li>
</ul>
<h3>Manage configurations</h3>
<ul>
<li>Update configuration records across EDL tables</li>
<li>Upload CSV data to configuration tables (audited)</li>
<li>Delete configuration records with a full audit trail</li>
<li>Download CSV templates for any table</li>
</ul>
<h3>Act on your behalf</h3>
<ul>
<li>Rerun failed jobs</li>
<li>Open Jira tickets with pre-filled context</li>
<li>Post run summaries to your Teams channel</li>
</ul>
<p>Every destructive action requires your explicit confirmation before execution.</p>`;
  }

  if (q.includes('etl') || q.includes('fail') || q.includes('diagnose') || q.includes('summariz')) {
    return `
<p>Over the last 24 hours I found <strong>3 failed jobs</strong> and <strong>7 with warnings</strong> across EDL.</p>
<h3>Failed</h3>
<ul>
<li><code>claims_ingest_hourly</code> — schema drift on <code>dob</code> (nullable → not null) at 02:14 UTC</li>
<li><code>member_360_build</code> — upstream <code>mdm.person</code> late by 38 minutes</li>
<li><code>risk_score_export</code> — S3 403 on target bucket (IAM rotation)</li>
</ul>
<p>Want me to rerun the first two and open a ticket for the IAM rotation?</p>`;
  }

  if (q.includes('python') || q.includes('code') || q.includes('script') || q.includes('reconcile')) {
    return `
<p>Here's a reconciliation script for <code>fact_claims</code> against the source of truth. It diffs primary keys, flags drift, and writes a report to S3.</p>
<pre class="code-block"><span class="com"># fact_claims_reconcile.py</span>
<span class="kw">from</span> edl <span class="kw">import</span> BigQueryClient, S3Writer
<span class="kw">import</span> pandas <span class="kw">as</span> pd

<span class="kw">def</span> <span class="fn">reconcile</span>(run_date: str) -&gt; <span class="str">"None"</span>:
    bq = BigQueryClient()
    tgt = bq.query(<span class="str">f"SELECT claim_id, amount FROM edl.fact_claims WHERE run_date='{run_date}'"</span>)
    src = bq.query(<span class="str">f"SELECT claim_id, amount FROM raw.claims WHERE run_date='{run_date}'"</span>)
    diff = tgt.merge(src, on=<span class="str">"claim_id"</span>, how=<span class="str">"outer"</span>, indicator=<span class="kw">True</span>)
    drift = diff[diff[<span class="str">"_merge"</span>] != <span class="str">"both"</span>]
    S3Writer().write_parquet(drift, <span class="str">f"s3://edl-recon/{run_date}.parquet"</span>)
    <span class="fn">print</span>(<span class="str">f"Reconciled {len(tgt)} rows · {len(drift)} drifted"</span>)

<span class="kw">if</span> __name__ == <span class="str">"__main__"</span>:
    reconcile(<span class="str">"2026-04-22"</span>)
</pre>
<p>Want me to open a PR to <code>edl-data-ops/recon</code>?</p>`;
  }

  if (q.includes('upload') || q.includes('csv')) {
    return `
<p>Ready. Target: <code>edl.orchestrator_config</code>.</p>
<ul>
<li>Expected columns: <code>job_id, cron, owner, is_active, updated_by</code></li>
<li>Primary key: <code>job_id</code> — upsert on conflict</li>
<li>Audit row written to <code>orchestrator_config_audit</code></li>
</ul>
<p>Drop the CSV here or paste a path. I'll dry-run a diff first — <strong>nothing writes without your go-ahead</strong>.</p>`;
  }

  return `<p>Got it. Let me think about <em>"${escapeHtml(text)}"</em> — could you share a bit more context? For example: a specific table, a time window, or an existing job ID.</p>`;
}

// -------------------- HTML utilities --------------------

export const stripHtml = (s) => {
  if (typeof document === 'undefined') return String(s);
  const d = document.createElement('div');
  d.innerHTML = s;
  return d.textContent || '';
};
